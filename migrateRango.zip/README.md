## Requirements

You need to have the Basic knowladge on neo4j and arangoDb

Install packages : npm install

Run : node index.js

debug press F5

## Getting started